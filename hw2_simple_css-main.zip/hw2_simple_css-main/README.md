# hw2_simple_css
Starter code for simple css assignment
